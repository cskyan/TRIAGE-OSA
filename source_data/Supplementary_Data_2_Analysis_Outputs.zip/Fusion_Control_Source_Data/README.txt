Fusion-control source data

The internal comparison uses four protein partitions and three optimization seeds within the fixed discovery-selected candidate universe.
cv_metrics.tsv contains train, validation and test results for both the 500-protein universe and the primary 250-protein subset.
Full denotes the structure trained under the shared BCE-plus-ranking objective. Native_full retains the original objective and budget as a reference.
The composite utility is 0.75 times target Spearman correlation plus 0.25 times backbone-ranking correlation minus 0.15 times soft-label BCE.
All 156 tuning trials and their selected refit settings are retained. Fold-seed spread is descriptive, not independent patient replication.

The CPAP and tissue tables evaluate fixed discovery rankings. Top-rank selection precedes intersection with the common measurable background.
The moderated CPAP comparisons and unmoderated paired-statistic participant bootstrap use distinct estimators. The latter intervals are not intervals for the moderated point estimate.
BH correction includes 20 CPAP comparisons; 50 tissue comparisons form a separate family. Bootstrap intervals are not multiplicity-adjusted.
All external comparisons are retained, including negative and discordant results. External evaluation is exploratory and does not measure clinical prediction accuracy.

The source_manifest.json records the identities and checksums of the supplied data files. Supplementary Fig. S1 and Tables S4-S6 and S14-S17 describe their manuscript use.
