Source records for Figures 9 and 10

These files are exports of archived inference outputs, not a new experiment.
The complete profiles retain all scored positions for UBE2Q2 (375) and VAMP7 (220), including residues outside coordinate coverage. Partner A/B profile tables follow the source shard protein order identified in case_provenance.json.
Native NPZ arrays retain archived dtypes and values. L1 and L2 projections were archived at float16 precision. Sparse L2 records contain 64 selected residue pairs per case; they are not a complete dense interface map or experimentally measured contacts. Stored probabilities are model quantities, not calibrated binding probabilities.
Native indices are zero-based; TSV files also provide one-based sequence positions. Original 100-pair source shards are retained and identified by SHA-256; only the named case row is used in each figure.
Coordinate mapping files cover experimentally resolved positions; complete profile files cover the evaluated sequence. The molecular backbone checkpoint identity does not by itself establish the training exposure history of its parent checkpoints.
