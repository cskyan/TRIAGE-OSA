# Structural-source verification

This archived audit concerns the UBE2Q2 (PDB 1ZUO, chain A) and VAMP7
(PDB 2DMW, chain A) localization figures. It did not retrain the model,
repeat inference, rerank candidates or change the figures.

## Verified records

- SHA-256 hashes of the full FASTA, 512-position input FASTA and sequence
  manifest agree with the archive dated 15 July 2026.
- Rendering sequences match the archived FASTA. Neither UBE2Q2 nor VAMP7
  was truncated. The BRCA1 partner used its first 512 N-terminal positions.
- Hashes of the pair registry, score table, evidence manifest, two residue
  shards and model checkpoint agree with the archived records.
- Plotted residue scores match the original shards and saved NPY arrays.
- Adding one to the archived zero-based Top-16 indices reproduces the
  one-based figure positions exactly.
- Coordinate checks retain 162 UBE2Q2 positions, including 11 Top-16
  positions, and 117 VAMP7 positions, including four Top-16 positions.
- VAMP7 author residue 105 is PRO, whereas reference position 98 is L.
  This mismatched position was already excluded from score coloring.

## Scope of the provenance record

Inference consumed ESM arrays rather than FASTA files directly. The archive
does not contain a sequence-hash-to-embedding-hash generation record for
every historical array. The audit records current array hashes and checks
dimensions, archived asset identities, sequences and downstream scores; a
newly recorded hash does not authenticate the historical embedding-generation
event. This distinction is not evidence of a sequence error. Additional
verification could use historical ESM logs or regenerate the two embeddings
from the archived sequences and matching ESM weights, independently of OSA
model training.

## Files and interpretation

- `audit_report.json`: checks, source identifiers and archived/current hashes.
- `verified_residue_mapping.tsv`: residue and score-index correspondence.
- `scripts/audit_osa_structure_provenance.py`: historical audit script identifier.
  That script is not included in this data archive.

Colors encode model residue scores, not experimentally established binding
sites. Neither structure is a complex of the named candidate protein pair.
Machine-specific path prefixes in the public copy use the aliases documented
in `PUBLIC_RELEASE_NOTES.md`; source hashes and numerical results are retained.
