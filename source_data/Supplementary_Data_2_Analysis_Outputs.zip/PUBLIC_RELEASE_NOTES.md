# Public-copy preparation

These files retain the archived study results. Public-copy preparation replaced
machine-specific path prefixes in provenance metadata with the logical aliases
below and translated the structural-source README into English. No model was
trained and no result was recomputed.

- `osa_workspace/`: original OSA analysis workspace, with its relative
  `results/`, `model/` and `model_assets/` locations retained.
- `backbone_workspace/`: historical molecular-model workspace.
- `manuscript/`: manuscript figure and source-record workspace.
- `candidate_evidence/`: the candidate-evidence archive contents.

Aliases identify historical sources; they do not imply that every referenced
external asset is distributed in this archive. Original hashes embedded in
historical manifests remain historical hashes and may differ for metadata
whose paths were normalized. `PUBLIC_FILE_MANIFEST.tsv` records both original
and distributed member hashes. Numerical tables, compressed result matrices,
and native structural arrays are unchanged byte for byte.
