# TRIAGE OSA candidate evidence source data

This package accompanies the candidate-module results and Supplementary Note 5, Section 5.3. It retains all 31,125 primary pairs and the original 15 displayed edges. No models were retrained and no ranking or selection rule was changed during packaging.

## Starting points

- `10_candidate_follow_up.tsv`: all 15 original edges with stable UniProt pair identifiers, genes, modules, original priority, molecular/context summaries, evidence coverage, rank ranges, top-set frequencies and evidence-family sensitivity.
- `11_candidate_evidence_states.tsv`: 135 edge-by-axis records. Unavailable, supportive and measured-not-supportive are separate states. A non-supportive flag is not a statistically significant opposite effect. No new opposite-direction labels or p values were inferred from threshold flags.
- `01_complete_pair_evidence.tsv.gz`: complete exported evidence, including continuous support variables, binary flags, gates, expert weights and traceability fields. Original implementation/version labels are retained as provenance, not manuscript terminology.
- `02_original_pareto_pairs.tsv` and `03_original_modules.tsv`: original Pareto candidates and module definitions.
- `04_complete_rank_stability.tsv.gz` and `05_all_adapter_logits.tsv.gz`: all primary-pair rank summaries and the 12 archived-adapter outputs.
- `06_shortlist_membership_by_run.tsv`: run-specific membership under fixed external evidence; this is distinct from simple Top-k ranking frequency.
- `07_evidence_family_dependence.tsv`: retention of original candidates after each evidence-family deletion, summarized over five deletions.
- `08_seed_and_partition_comparisons.tsv`: within-fold seed and between-fold comparisons.
- `09_protein_evidence.tsv`: protein-level evidence underlying the pair summaries.

## Interpretation and reuse

Join by `pair_id`, not row number or gene symbol. The accession pair identifies an unordered protein pair. Smaller original rank is better. The OSA priority score is not a calibrated physical-interaction or patient-risk probability. `structural_score` is the exported mean molecular branch probability, not experimentally measured structure quality. `osa_context_score` is the existing context summary used for Pareto selection and must not be substituted for the final OSA priority.

Top-k frequencies have denominator 12 (four folds and three seeds), with a fixed discovery-selected protein universe. These runs are not independent biological replications. Rank stability is not an interaction probability. The evidence breadth denominator remains nine, including unavailable axes. `evidence_conflict_count` and source conflict flags describe the original threshold disagreements, not significance tests. The five evidence-family deletions are sensitivity settings, not five new cohorts.

For follow-up selection, first inspect assay availability and context, then compare original rank, full rank range and evidence dependence. Select an independent cohort and a biological compartment before evaluating expression correspondence. Test physical binding separately from expression association. Keep discordant candidates as informative comparison cases. These files do not prescribe a clinical diagnostic threshold or a newly optimized candidate list.

`source_manifest.tsv` records relative archive sources and SHA-256 for byte-identical source copies. The two reader-facing tables are derived by identifier joins and deterministic reshaping. Missing values remain missing. Their numerical contents were checked against the source tables. Public hosting and a persistent repository identifier remain an author submission step; a local package is not itself a public repository.

## Same-background comparison (Supplementary Note 5, Section 5.4)

- `15_candidate_method_comparison.tsv`: all 15 original displayed edges, four method ranks, original Full top-5% frequencies and evidence coverage.
- `16_method_selection_summary.tsv`: equal-budget top-312 and top-1,557 overlap and counts after the same fixed Pareto filter.
- `17_complete_method_rankings.tsv.gz`: complete primary-pair rankings for Full, converged constrained-static fusion, Direct anchor and backbone PPI.
- `18_comparison_reconstruction_checks.tsv`: 24 regression checks against archived CPAP endpoint summaries.
- `19_candidate_comparison_provenance.json`: input checksum, static weights, rank provenance and reconstruction tolerance.

These files are newly derived comparisons, separately checksummed in `candidate_comparison_manifest.tsv`; they are not byte-identical archive copies listed in the original source manifest. Full and PPI ranks are retained from the original exports. Static and Anchor rankings use stable archived pair order for ties. No model was refitted, and no external outcome was used to select a new candidate. Later cross-participant retrained models are outside this comparison. Full and Static share 1,432/1,557 top-5% pairs (92.0%); their Jaccard overlap is 0.8514. All 15 original displayed edges also occur in Static's top-5% set. These descriptive results do not establish superior biological accuracy or unique discovery by adaptive fusion.


## Candidate-level audit (Section 5.5; Fig. 8)

- `20_case_node_direction.tsv`: archived node coefficients, oriented moderated t statistics and node percentiles for four proteins.
- `21_case_heatmap_source.tsv`: plotted direction statistics, preserving unavailable values.
- `22_case_evidence_provenance.json`: source checksums, selection rationale and interpretation.

These are descriptive re-expressions of archived results, not new independent validation. The two adipose disease-state axes share participants. Relative support does not imply that both endpoint raw statistics are positive.

## Candidate expression-evidence assessment (Table S25)

- `38_candidate_evidence_status.tsv`: per-candidate D/M/U states in original rank order; no clinical grade or new ranking.
- `39_candidate_evidence_assessment_rules.json`: exact assessment rules, scope, source hashes and record counts.
- `40_candidate_node_statistics.tsv`: all 153 gene-by-context records for 17 proteins, including 142 evaluable results, original coefficients, SE where exported, P values and gene-wide BH values.
- `41_candidate_context_evidence_status.tsv`: all 135 pair-by-context records, including individual endpoint effects and adjusted values.

D denotes direction concordance without joint gene-level statistical support; M denotes measured but not jointly direction-concordant; U denotes unavailable measurement for at least one endpoint. No available candidate-gene test met the original within-contrast BH threshold of 0.05. These are post hoc descriptive annotations, not clinical evidence grades. Existing percentile-support flags, model ranks, shortlist and aggregate endpoint analyses are unchanged. The superseded E1–E4 classification and its two derived files have been withdrawn. Use the assessment files above.
