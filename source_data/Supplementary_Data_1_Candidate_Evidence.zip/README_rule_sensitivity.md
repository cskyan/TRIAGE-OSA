# Candidate support-rule sensitivity extension

This extension accompanies Supplementary Note 5.2.4 and Tables S23 and S24. The original 01–22 files, rankings and displayed 15 edges remain unchanged.

## Files

- 23: counts for every rule, including retained, lost and added original candidates, Jaccard overlap and connected-component sizes.
- 24: all 15 original candidates, rank ranges, top-5% frequency across 12 existing adapters, evidence-family dependence, and membership under all rules.
- 25: complete 31,125-pair evidence breadth, Pareto and shortlist membership under every rule.
- 26: selected pairs under all rules, with original membership flags.
- 27: endpoint direction and score reconstruction records, including eligible single-cell lineages.
- 28: input, code and protocol SHA-256 identities and reconstruction status.
- 29: independent reproduction of the original protein-selection strengths and complete ranking.
- 30: original expression-axis score and single-cell lineage-count reconstruction checks.
- rule_sensitivity_protocol.md: definitions and the documented cohort-identity correction made before the final run.
- rule_extension_manifest.tsv: checksums for this extension only. Existing manifests still apply to their original files.

## Scope

The direction rule retains 9/15 original edges; the shared-source rule retains 15/15; their combination retains 9/15. Each rule recomputes Pareto membership across the entire universe before intersecting with the original first 1,557 ranks. A stricter support definition can add a formerly dominated pair; lists need not be nested. Retention is conditional rule sensitivity, not a validation probability. The two shared disease-state adipose views are grouped; the separate 24-participant adipose treatment cohort is not.

## Reproduction from the OSA project root

Python 3.8 or later with numpy and pandas is required. No GPU or model fitting is used. Preserve the archived input stages listed in 28_rule_provenance.json, the model function and protocol file. To avoid overwriting the completed result, choose a new output directory:

```sh
python scripts/osa_shortlist_rule_sensitivity.py --root . --output-stage 46_shortlist_rule_sensitivity_recheck
```

The program refuses an existing output directory and stops if original reconstruction fails. Compare the recomputed rule_summary.tsv to file 23. Compressed-file bytes can vary because of gzip metadata; compare decoded tables when checking reruns. The original 15-edge list is selected by original_selected in file 25 and by setting=original in file 26. No additional modelling is required to read or reconstruct those tables.
