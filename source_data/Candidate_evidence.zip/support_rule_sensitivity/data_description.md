# Candidate support-rule sensitivity extension

This extension accompanies Supplementary Note 5.2.4 and Tables S23 and S24. The original candidate-evidence files, rankings and displayed 15 edges remain unchanged.

## Files

- `rule_summary.tsv`: counts for every rule, including retained, lost and added original candidates, Jaccard overlap and connected-component sizes.
- `candidate_rule_sensitivity.tsv`: all 15 original candidates, rank ranges, top-5% frequency across 12 existing adapters, evidence-family dependence, and membership under all rules.
- `complete_rule_membership.tsv.gz`: complete 31,125-pair evidence breadth, Pareto and shortlist membership under every rule.
- `selected_pairs_by_rule.tsv`: selected pairs under all rules, with original membership flags.
- `endpoint_direction_scores.tsv.gz`: endpoint direction and score reconstruction records, including eligible single-cell lineages.
- `rule_settings.json`: input, code and protocol identifiers and reconstruction status.
- `protein_selection_reproduction.json`: independent reproduction of the original protein-selection strengths and complete ranking.
- `support_score_reproduction.tsv`: original expression-axis score and single-cell lineage-count reconstruction checks.
- protocol.md: definitions and the documented cohort-identity correction made before the final run.

## Scope

The direction rule retains 9/15 original edges; the shared-source rule retains 15/15; their combination retains 9/15. Each rule recomputes Pareto membership across the entire universe before intersecting with the original first 1,557 ranks. A stricter support definition can add a formerly dominated pair; lists need not be nested. Retention is conditional rule sensitivity, not a validation probability. The two shared disease-state adipose views are grouped; the separate 24-participant adipose treatment cohort is not.

## Reproduction from the OSA project root

Python 3.8 or later with numpy and pandas is required. No GPU or model fitting is used. Preserve the archived input stages listed in rule_settings.json, the model function and protocol file. To avoid overwriting the completed result, choose a new output directory:

```sh
python scripts/osa_shortlist_rule_sensitivity.py --root . --output-stage support_rule_sensitivity_reproduction
```

The program refuses an existing output directory and stops if original reconstruction fails. Compare the recomputed rule_summary.tsv to `rule_summary.tsv`. Compressed-file bytes can vary because of gzip metadata; compare decoded tables when checking reruns. The original 15-edge list is selected by original_selected in `complete_rule_membership.tsv.gz` and by setting=original in `selected_pairs_by_rule.tsv`. No additional modelling is required to read or reconstruct those tables.
