# Candidate rule sensitivity analysis

Protocol written before computing the new shortlist results on 26 September 2026.

## Fixed inputs and scope

Use the archived primary 31,125 pairs, their molecular and context percentile coordinates, and original Full ranking. Recompute the non-dominated set over all pairs for every rule, then intersect with the original first 1,557 ranks. Do not train, alter ranks, alter candidates, optimize thresholds, or overwrite original outputs. First reproduce exactly the archived 32 Pareto pairs and 15 module edges.

## Primary four settings

1. Original nine-axis relative support and fixed denominator nine.
2. Direction-qualified support. For each expression axis require the original relative support rule and strictly positive direction-oriented statistics for both endpoints. Zero is not positive. For the single-cell axis, set a lineage's pair support to zero when either oriented endpoint statistic is non-positive; average over the original eligible lineages and retain the original threshold above 0.5. Missing lineages remain unavailable, not zero observations. Proteomic and interaction reference rules are unchanged.
3. Participant-source grouping. Replace subcutaneous adipose disease state and visceral adipose disease state with their arithmetic mean binary support, including unavailable views as zero as in the original fixed-denominator definition. These two disease-state views share 18 participants. Adipose CPAP is a separate 24-participant treatment cohort and remains a separate axis. Average this grouped contribution and the other seven axes with denominator eight. Preserve all separate tissue and contrast records. This is equal source-group weighting, not an estimate of statistical independence or biological replication.
4. Apply direction qualification and participant-source grouping together.

## Prespecified secondary checks

- Original relative support divided by the number of available axes, with zero for no available axes, to recover the existing coverage-normalization sensitivity on the same background.

## Source correction before the final run

The first diagnostic run incorrectly grouped the separate adipose CPAP cohort with the two disease-state views. On checking the main manuscript and source design, this was corrected because GSE135917 Study Group 1 and GSE38792 share 18 participants, whereas GSE135917 treatment Study Group 2 has 24 participants. The erroneous three-view grouping is excluded from manuscript results. The correction concerns cohort identity, not the observed retention counts. The initial diagnostic output is retained locally in Stage46 v1; final corrected results are generated in Stage46 v2. No choice among alternative grouping rules is based on candidate retention.

## Reporting

Report every setting, entire non-dominated set, selected and added/deleted edges, node/component counts, original-15 retention, Jaccard overlap and all original candidates' ranks, 12-run frequencies, coverage and support-source records. No significance test is attached to deterministic rule changes. Different membership is reported as rule dependence; unchanged membership is not independent validation. Exact original reproduction is a mandatory execution gate.
